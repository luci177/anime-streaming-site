import type { Metadata } from "next"
import { AnimeGrid } from "@/components/anime-grid"
import { generateSEOMetadata } from "@/lib/seo"

export const metadata: Metadata = generateSEOMetadata({
  title: "Completed Anime",
  description: "Browse completed anime series that have finished airing. Binge-watch complete anime shows.",
  path: "/completed",
})

export default function CompletedPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-4">Completed Anime</h1>
          <p className="text-muted-foreground text-lg">
            Discover completed anime series that you can binge-watch from start to finish.
          </p>
        </div>

        <AnimeGrid endpoint="completed" title="Completed Series" showTitle={false} />
      </div>
    </div>
  )
}
