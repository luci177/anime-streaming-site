import type { Metadata } from "next"
import { AnimeGrid } from "@/components/anime-grid"
import { generateSEOMetadata } from "@/lib/seo"

export const metadata: Metadata = generateSEOMetadata({
  title: "Popular Anime",
  description: "Discover the most popular anime series of all time. Watch highly rated and beloved anime shows.",
  path: "/popular",
})

export default function PopularPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-4">Most Popular</h1>
          <p className="text-muted-foreground text-lg">
            Explore the most popular and highly-rated anime series loved by fans worldwide.
          </p>
        </div>

        <AnimeGrid endpoint="popular" title="Most Popular" showTitle={false} />
      </div>
    </div>
  )
}
