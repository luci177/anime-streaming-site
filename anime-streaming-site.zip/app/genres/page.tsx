import type { Metadata } from "next"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { generateSEOMetadata } from "@/lib/seo"

export const metadata: Metadata = generateSEOMetadata({
  title: "Anime Genres",
  description: "Browse anime by genres. Find your favorite anime series by action, romance, comedy, drama and more.",
  path: "/genres",
})

const genres = [
  { name: "Action", slug: "action", count: "2,450+" },
  { name: "Adventure", slug: "adventure", count: "1,890+" },
  { name: "Comedy", slug: "comedy", count: "1,670+" },
  { name: "Drama", slug: "drama", count: "2,100+" },
  { name: "Fantasy", slug: "fantasy", count: "1,340+" },
  { name: "Romance", slug: "romance", count: "980+" },
  { name: "Sci-Fi", slug: "sci-fi", count: "760+" },
  { name: "Slice of Life", slug: "slice-of-life", count: "890+" },
  { name: "Supernatural", slug: "supernatural", count: "1,200+" },
  { name: "Thriller", slug: "thriller", count: "650+" },
  { name: "Horror", slug: "horror", count: "420+" },
  { name: "Mystery", slug: "mystery", count: "580+" },
  { name: "Sports", slug: "sports", count: "340+" },
  { name: "Music", slug: "music", count: "180+" },
  { name: "Mecha", slug: "mecha", count: "290+" },
  { name: "Historical", slug: "historical", count: "210+" },
]

export default function GenresPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-4">Browse by Genre</h1>
          <p className="text-muted-foreground text-lg">
            Explore anime series by your favorite genres and discover new shows to watch.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {genres.map((genre) => (
            <Link key={genre.slug} href={`/genres/${genre.slug}`}>
              <Card className="hover:bg-accent transition-colors cursor-pointer">
                <CardContent className="p-6 text-center">
                  <h3 className="font-semibold text-lg mb-2">{genre.name}</h3>
                  <p className="text-sm text-muted-foreground">{genre.count} anime</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
