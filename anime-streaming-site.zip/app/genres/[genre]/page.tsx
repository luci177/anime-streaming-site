import type { Metadata } from "next"
import { AnimeGrid } from "@/components/anime-grid"
import { generateSEOMetadata } from "@/lib/seo"
import { notFound } from "next/navigation"

const validGenres = [
  "action",
  "adventure",
  "comedy",
  "drama",
  "fantasy",
  "romance",
  "sci-fi",
  "slice-of-life",
  "supernatural",
  "thriller",
  "horror",
  "mystery",
  "sports",
  "music",
  "mecha",
  "historical",
]

interface GenrePageProps {
  params: {
    genre: string
  }
}

export async function generateMetadata({ params }: GenrePageProps): Promise<Metadata> {
  const genre = params.genre
  const genreName = genre
    .split("-")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")

  return generateSEOMetadata({
    title: `${genreName} Anime`,
    description: `Discover the best ${genreName.toLowerCase()} anime series. Watch popular ${genreName.toLowerCase()} anime online.`,
    path: `/genres/${genre}`,
  })
}

export default function GenrePage({ params }: GenrePageProps) {
  const { genre } = params

  if (!validGenres.includes(genre)) {
    notFound()
  }

  const genreName = genre
    .split("-")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-4">{genreName} Anime</h1>
          <p className="text-muted-foreground text-lg">
            Explore the best {genreName.toLowerCase()} anime series and discover your next favorite show.
          </p>
        </div>

        <AnimeGrid endpoint={`genre/${genre}`} title={`${genreName} Anime`} showTitle={false} />
      </div>
    </div>
  )
}
