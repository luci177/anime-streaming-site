"use client"

import { Navbar } from "@/components/navbar"
import { HeroSection } from "@/components/hero-section"
import { AnimeGrid } from "@/components/anime-grid"
import { AutoUpdateIndicator } from "@/components/auto-update-indicator"
import { useTrendingAnime } from "@/hooks/use-auto-update"
import { Skeleton } from "@/components/ui/skeleton"

export default function HomePage() {
  const { anime: trendingAnime, loading, lastUpdated } = useTrendingAnime()

  const featuredAnime = trendingAnime.slice(0, 5) // Top 5 for hero carousel
  const gridAnime = trendingAnime.slice(5) // Rest for the grid

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      {loading ? (
        <div className="h-[70vh] min-h-[500px] bg-muted animate-pulse" />
      ) : (
        <HeroSection featuredAnime={featuredAnime} />
      )}

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
        {/* Trending Anime Grid */}
        <section className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="font-serif font-bold text-2xl text-foreground">Trending Now</h2>
            <AutoUpdateIndicator lastUpdated={lastUpdated} isLoading={loading} />
          </div>

          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {Array.from({ length: 18 }).map((_, i) => (
                <div key={i} className="space-y-2">
                  <Skeleton className="aspect-[3/4] w-full" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-3 w-2/3" />
                </div>
              ))}
            </div>
          ) : (
            <AnimeGrid anime={gridAnime} showTitle={false} />
          )}
        </section>
      </main>
    </div>
  )
}
