import { notFound } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { animeAPI } from "@/lib/api"
import { generateAnimeMetadata, generateAnimeStructuredData } from "@/lib/seo"
import { StructuredData } from "@/components/structured-data"
import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Play, Star, Calendar, Tv, Users } from "lucide-react"

interface AnimePageProps {
  params: { id: string }
}

export async function generateMetadata({ params }: AnimePageProps) {
  const animeId = Number.parseInt(params.id)
  if (isNaN(animeId)) {
    return {
      title: "Anime Not Found - AnimeVerse",
      description: "The requested anime could not be found.",
    }
  }

  const anime = await animeAPI.getAnimeDetails(animeId)
  if (!anime) {
    return {
      title: "Anime Not Found - AnimeVerse",
      description: "The requested anime could not be found.",
    }
  }

  return generateAnimeMetadata(anime)
}

export default async function AnimePage({ params }: AnimePageProps) {
  const animeId = Number.parseInt(params.id)
  if (isNaN(animeId)) {
    notFound()
  }

  const anime = await animeAPI.getAnimeDetails(animeId)
  if (!anime) {
    notFound()
  }

  const title = anime.title.english || anime.title.romaji
  const score = anime.averageScore ? (anime.averageScore / 10).toFixed(1) : null
  const studio = anime.studios.nodes[0]?.name
  const structuredData = generateAnimeStructuredData(anime)

  return (
    <>
      <StructuredData data={structuredData} />
      <div className="min-h-screen bg-background">
        <Navbar />

        {/* Hero Section */}
        <section className="relative h-[50vh] min-h-[400px] overflow-hidden">
          <div className="absolute inset-0">
            <Image
              src={anime.bannerImage || anime.coverImage.large}
              alt={title}
              fill
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/50 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
          </div>

          <div className="relative z-10 h-full flex items-end">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pb-12">
              <div className="flex flex-col md:flex-row gap-8 items-end">
                {/* Cover Image */}
                <div className="flex-shrink-0">
                  <div className="relative w-48 h-64 rounded-lg overflow-hidden shadow-2xl">
                    <Image
                      src={anime.coverImage.large || "/placeholder.svg"}
                      alt={title}
                      fill
                      className="object-cover"
                    />
                  </div>
                </div>

                {/* Info */}
                <div className="flex-1 space-y-4">
                  <div className="flex items-center gap-3">
                    <Badge variant={anime.status === "RELEASING" ? "default" : "secondary"}>
                      {anime.status === "RELEASING" ? "Ongoing" : "Completed"}
                    </Badge>
                    {score && (
                      <div className="flex items-center gap-1 bg-black/50 backdrop-blur-sm rounded-full px-3 py-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium text-white">{score}</span>
                      </div>
                    )}
                  </div>

                  <h1 className="font-serif font-black text-3xl md:text-5xl text-foreground">{title}</h1>

                  <div className="flex flex-wrap gap-2">
                    {anime.genres.map((genre) => (
                      <Badge key={genre} variant="outline">
                        {genre}
                      </Badge>
                    ))}
                  </div>

                  <Button asChild size="lg" className="bg-primary hover:bg-primary/90">
                    <Link href={`/watch/${anime.id}`}>
                      <Play className="w-5 h-5 mr-2 fill-current" />
                      Watch Now
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Content */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Description */}
              <Card>
                <CardContent className="p-6">
                  <h2 className="font-serif font-bold text-xl mb-4">Synopsis</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    {anime.description?.replace(/<[^>]*>/g, "") || "No description available."}
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <Card>
                <CardContent className="p-6 space-y-4">
                  <h3 className="font-serif font-bold text-lg">Information</h3>

                  <div className="space-y-3">
                    {anime.seasonYear && (
                      <div className="flex items-center gap-3">
                        <Calendar className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">Year:</span>
                        <span className="text-sm font-medium">{anime.seasonYear}</span>
                      </div>
                    )}

                    {anime.episodes && (
                      <div className="flex items-center gap-3">
                        <Tv className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">Episodes:</span>
                        <span className="text-sm font-medium">{anime.episodes}</span>
                      </div>
                    )}

                    {studio && (
                      <div className="flex items-center gap-3">
                        <Users className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">Studio:</span>
                        <span className="text-sm font-medium">{studio}</span>
                      </div>
                    )}

                    <div className="flex items-center gap-3">
                      <span className="text-sm text-muted-foreground">Format:</span>
                      <span className="text-sm font-medium">{anime.format}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </>
  )
}
