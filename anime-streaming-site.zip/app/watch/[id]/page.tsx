"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { notFound } from "next/navigation"
import { generateEpisodeStructuredData } from "@/lib/seo"
import { StructuredData } from "@/components/structured-data"
import { Navbar } from "@/components/navbar"
import { VideoPlayer } from "@/components/video-player"
import { EpisodeList } from "@/components/episode-list"
import { AutoUpdateIndicator } from "@/components/auto-update-indicator"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { useAnimeDetails, useAnimeEpisodes } from "@/hooks/use-auto-update"
import { animeAPI } from "@/lib/api"
import type { Episode, StreamingData } from "@/lib/api"

interface WatchPageProps {
  params: { id: string }
}

export default function WatchPage({ params }: WatchPageProps) {
  const searchParams = useSearchParams()
  const episodeParam = searchParams.get("ep")

  const animeId = Number.parseInt(params.id)
  const { anime, loading: animeLoading, lastUpdated: animeLastUpdated } = useAnimeDetails(animeId)
  const { episodes, loading: episodesLoading, lastUpdated: episodesLastUpdated } = useAnimeEpisodes(animeId.toString())

  const [currentEpisode, setCurrentEpisode] = useState<Episode | null>(null)
  const [streamingData, setStreamingData] = useState<StreamingData | null>(null)
  const [streamingLoading, setStreamingLoading] = useState(false)

  useEffect(() => {
    if (isNaN(animeId)) {
      notFound()
      return
    }
  }, [animeId])

  useEffect(() => {
    if (anime && currentEpisode) {
      const title = anime.title.english || anime.title.romaji
      const episodeTitle = `Watch ${title} Episode ${currentEpisode.number} Online Free - AnimeVerse`
      const description = `Watch ${title} Episode ${currentEpisode.number} online for free in HD quality. Stream the latest episodes with English subtitles.`

      document.title = episodeTitle

      // Update meta description
      let metaDescription = document.querySelector('meta[name="description"]')
      if (!metaDescription) {
        metaDescription = document.createElement("meta")
        metaDescription.setAttribute("name", "description")
        document.head.appendChild(metaDescription)
      }
      metaDescription.setAttribute("content", description)
    }
  }, [anime, currentEpisode])

  useEffect(() => {
    if (episodes.length > 0) {
      // Set initial episode
      const episodeNumber = episodeParam ? Number.parseInt(episodeParam) : 1
      const initialEpisode = episodes.find((ep) => ep.number === episodeNumber) || episodes[0]

      if (initialEpisode) {
        setCurrentEpisode(initialEpisode)
      }
    }
  }, [episodes, episodeParam])

  useEffect(() => {
    if (!currentEpisode) return

    const loadStreamingData = async () => {
      setStreamingLoading(true)
      try {
        const data = await animeAPI.getStreamingData(currentEpisode.id)
        setStreamingData(data)
      } catch (error) {
        console.error("Error loading streaming data:", error)
        setStreamingData(null)
      } finally {
        setStreamingLoading(false)
      }
    }

    loadStreamingData()
  }, [currentEpisode])

  const handleEpisodeSelect = (episode: Episode) => {
    setCurrentEpisode(episode)
    // Update URL without page reload
    const url = new URL(window.location.href)
    url.searchParams.set("ep", episode.number.toString())
    window.history.replaceState({}, "", url.toString())
  }

  const handlePreviousEpisode = () => {
    if (!currentEpisode || !episodes.length) return
    const currentIndex = episodes.findIndex((ep) => ep.number === currentEpisode.number)
    if (currentIndex > 0) {
      handleEpisodeSelect(episodes[currentIndex - 1])
    }
  }

  const handleNextEpisode = () => {
    if (!currentEpisode || !episodes.length) return
    const currentIndex = episodes.findIndex((ep) => ep.number === currentEpisode.number)
    if (currentIndex < episodes.length - 1) {
      handleEpisodeSelect(episodes[currentIndex + 1])
    }
  }

  const hasPrevious = currentEpisode ? episodes.findIndex((ep) => ep.number === currentEpisode.number) > 0 : false
  const hasNext = currentEpisode
    ? episodes.findIndex((ep) => ep.number === currentEpisode.number) < episodes.length - 1
    : false

  if (animeLoading || episodesLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <Skeleton className="aspect-video w-full" />
              <div className="space-y-2">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            </div>
            <div className="space-y-4">
              <Skeleton className="h-8 w-32" />
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          </div>
        </main>
      </div>
    )
  }

  if (!anime) {
    notFound()
  }

  const title = anime.title.english || anime.title.romaji
  const structuredData = currentEpisode ? generateEpisodeStructuredData(anime, currentEpisode.number) : null

  return (
    <>
      {structuredData && <StructuredData data={structuredData} />}
      <div className="min-h-screen bg-background">
        <Navbar />

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Video Player Section */}
            <div className="lg:col-span-2 space-y-6">
              {/* Video Player */}
              {streamingLoading ? (
                <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                  <div className="text-center space-y-2">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                    <p className="text-muted-foreground">Loading episode...</p>
                  </div>
                </div>
              ) : (
                <VideoPlayer
                  streamingData={streamingData}
                  title={title}
                  episodeNumber={currentEpisode?.number || 1}
                  onPrevious={handlePreviousEpisode}
                  onNext={handleNextEpisode}
                  hasPrevious={hasPrevious}
                  hasNext={hasNext}
                />
              )}

              {/* Episode Info */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h1 className="font-serif font-bold text-2xl mb-2">{title}</h1>
                      {currentEpisode && (
                        <h2 className="text-lg text-muted-foreground">
                          Episode {currentEpisode.number}
                          {currentEpisode.title && ` - ${currentEpisode.title}`}
                        </h2>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Badge variant={anime.status === "RELEASING" ? "default" : "secondary"}>
                        {anime.status === "RELEASING" ? "Ongoing" : "Completed"}
                      </Badge>
                    </div>
                  </div>

                  {currentEpisode?.description && (
                    <p className="text-muted-foreground leading-relaxed">{currentEpisode.description}</p>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Episodes Sidebar */}
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="font-serif font-bold text-lg">Episodes</h3>
                <AutoUpdateIndicator lastUpdated={episodesLastUpdated} isLoading={episodesLoading} />
              </div>

              <EpisodeList
                episodes={episodes}
                currentEpisode={currentEpisode?.number}
                onEpisodeSelect={handleEpisodeSelect}
                animeTitle={title}
              />
            </div>
          </div>
        </main>
      </div>
    </>
  )
}
