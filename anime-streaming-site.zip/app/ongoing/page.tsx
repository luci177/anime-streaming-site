import type { Metadata } from "next"
import { AnimeGrid } from "@/components/anime-grid"
import { generateSEOMetadata } from "@/lib/seo"

export const metadata: Metadata = generateSEOMetadata({
  title: "Ongoing Anime",
  description: "Watch currently airing anime series. Stay up to date with the latest episodes of ongoing anime.",
  path: "/ongoing",
})

export default function OngoingPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-4">Currently Airing</h1>
          <p className="text-muted-foreground text-lg">
            Stay up to date with currently airing anime series and never miss a new episode.
          </p>
        </div>

        <AnimeGrid endpoint="airing" title="Currently Airing" showTitle={false} />
      </div>
    </div>
  )
}
