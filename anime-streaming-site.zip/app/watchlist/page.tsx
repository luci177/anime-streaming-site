import type { Metadata } from "next"
import { AnimeGrid } from "@/components/anime-grid"
import { generateSEOMetadata } from "@/lib/seo"

export const metadata: Metadata = generateSEOMetadata({
  title: "My Watchlist",
  description: "Keep track of anime you want to watch. Manage your personal anime watchlist.",
  path: "/watchlist",
})

export default function WatchlistPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-4">My Watchlist</h1>
          <p className="text-muted-foreground text-lg">
            Keep track of anime series you want to watch and never forget a great recommendation.
          </p>
        </div>

        <div className="mb-6">
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span>12 anime in watchlist</span>
            <span>•</span>
            <span>Last updated 2 days ago</span>
          </div>
        </div>

        <AnimeGrid endpoint="watchlist" title="Your Watchlist" showTitle={false} />
      </div>
    </div>
  )
}
