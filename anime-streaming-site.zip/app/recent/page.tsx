import type { Metadata } from "next"
import { AnimeGrid } from "@/components/anime-grid"
import { generateSEOMetadata } from "@/lib/seo"

export const metadata: Metadata = generateSEOMetadata({
  title: "Recent Episodes",
  description: "Watch the latest anime episodes. Stay updated with recently released anime episodes.",
  path: "/recent",
})

export default function RecentPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-4">Recent Episodes</h1>
          <p className="text-muted-foreground text-lg">
            Catch up on the latest anime episodes that were recently released.
          </p>
        </div>

        <AnimeGrid endpoint="recent-episodes" title="Recent Episodes" showTitle={false} />
      </div>
    </div>
  )
}
