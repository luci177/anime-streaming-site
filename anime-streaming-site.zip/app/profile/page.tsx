import type { Metadata } from "next"
import { UserProfile } from "@/components/user-profile"
import { generateSEOMetadata } from "@/lib/seo"

export const metadata: Metadata = generateSEOMetadata({
  title: "My Profile",
  description: "View your anime watching statistics, favorites, and profile information.",
  path: "/profile",
})

const mockUserStats = {
  totalWatched: 127,
  totalEpisodes: 2840,
  averageRating: 8.4,
  favoriteGenres: ["Action", "Adventure", "Fantasy", "Drama", "Romance"],
  joinDate: "March 2023",
  watchTime: "1,420 hours",
}

export default function ProfilePage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <UserProfile username="AnimeExplorer" avatar="/anime-fan-avatar.png" stats={mockUserStats} />
      </div>
    </div>
  )
}
