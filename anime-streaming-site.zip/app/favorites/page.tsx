import type { Metadata } from "next"
import { AnimeGrid } from "@/components/anime-grid"
import { generateSEOMetadata } from "@/lib/seo"

export const metadata: Metadata = generateSEOMetadata({
  title: "My Favorites",
  description: "Your favorite anime series collection. Revisit your most loved anime shows.",
  path: "/favorites",
})

export default function FavoritesPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-4">My Favorites</h1>
          <p className="text-muted-foreground text-lg">
            Your collection of favorite anime series that you absolutely love.
          </p>
        </div>

        <div className="mb-6">
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span>8 favorite anime</span>
            <span>•</span>
            <span>Average rating: 9.2/10</span>
          </div>
        </div>

        <AnimeGrid endpoint="favorites" title="Your Favorites" showTitle={false} />
      </div>
    </div>
  )
}
