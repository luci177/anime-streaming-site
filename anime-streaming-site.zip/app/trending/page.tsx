import type { Metadata } from "next"
import { AnimeGrid } from "@/components/anime-grid"
import { generateSEOMetadata } from "@/lib/seo"

export const metadata: Metadata = generateSEOMetadata({
  title: "Trending Anime",
  description:
    "Discover the most trending and popular anime series right now. Stay updated with the latest anime trends.",
  path: "/trending",
})

export default function TrendingPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-4">Trending Anime</h1>
          <p className="text-muted-foreground text-lg">
            Discover the most popular and trending anime series that everyone is talking about.
          </p>
        </div>

        <AnimeGrid endpoint="trending" title="Trending Now" showTitle={false} />
      </div>
    </div>
  )
}
