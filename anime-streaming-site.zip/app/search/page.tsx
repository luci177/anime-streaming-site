import { Suspense } from "react"
import { animeAPI } from "@/lib/api"
import { generateSearchMetadata } from "@/lib/seo"
import { Navbar } from "@/components/navbar"
import { AnimeGrid } from "@/components/anime-grid"
import { Skeleton } from "@/components/ui/skeleton"

interface SearchPageProps {
  searchParams: { q?: string }
}

export async function generateMetadata({ searchParams }: SearchPageProps) {
  const query = searchParams.q || ""
  if (!query) {
    return {
      title: "Search Anime - AnimeVerse",
      description: "Search for your favorite anime series and movies. Watch online for free in HD quality.",
    }
  }

  const searchResults = await animeAPI.searchAnime(query, 1, 24)
  return generateSearchMetadata(query, searchResults.length)
}

async function SearchResults({ query }: { query: string }) {
  const searchResults = await animeAPI.searchAnime(query, 1, 24)

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="font-serif font-bold text-3xl text-foreground mb-2">Search Results</h1>
        <p className="text-muted-foreground">
          Found {searchResults.length} results for "{query}"
        </p>
      </div>

      <AnimeGrid anime={searchResults} showTitle={false} />
    </div>
  )
}

function SearchSkeleton() {
  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <Skeleton className="h-8 w-64 mx-auto" />
        <Skeleton className="h-4 w-48 mx-auto" />
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
        {Array.from({ length: 12 }).map((_, i) => (
          <div key={i} className="space-y-2">
            <Skeleton className="aspect-[3/4] w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-3 w-2/3" />
          </div>
        ))}
      </div>
    </div>
  )
}

export default function SearchPage({ searchParams }: SearchPageProps) {
  const query = searchParams.q || ""

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {query ? (
          <Suspense fallback={<SearchSkeleton />}>
            <SearchResults query={query} />
          </Suspense>
        ) : (
          <div className="text-center py-12">
            <h1 className="font-serif font-bold text-3xl text-foreground mb-4">Search Anime</h1>
            <p className="text-muted-foreground">Use the search bar above to find your favorite anime</p>
          </div>
        )}
      </main>
    </div>
  )
}
